import React, { Component } from 'react';

function NotFound() {
    return (
        <div>
            <h1>Not Fount</h1>
            Algo de errado não está certo. <br/>
            Esse endereço não está correto.<br/>
            Se estivesse, essa mensagem não apareceria <br/>
        </div>
    )
}
export default NotFound;