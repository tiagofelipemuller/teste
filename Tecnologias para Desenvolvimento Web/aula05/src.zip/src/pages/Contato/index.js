import React, { Component } from 'react';

function Contato() {
    return (
        <div>
            <h3>Contato</h3>
            Olá, me chamo Tiago. <br/>
            Telefone: 4002-8922<br/><br/>
            Sobre mim: Esse é meu nome porque minha mâe escolheu, se não seria outro.<br/><br/>
        </div>
    )
}
export default Contato;