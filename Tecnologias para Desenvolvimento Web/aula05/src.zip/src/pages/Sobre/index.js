import React, { Component } from 'react';

function Sobre() {
    return (
        <div>
            <h3>Sobre</h3>
            O site foi criado a partir do momento que comecei a desenvolvê-lo. <br/>
            Se eu não tivesse feito ele, ele não existiria. <br/>
            O site visa elogiar o melhor professor da PUCPR, <br/>
        </div>
    )
}
export default Sobre;