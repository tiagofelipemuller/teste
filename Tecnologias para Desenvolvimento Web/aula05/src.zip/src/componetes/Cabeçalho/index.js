import React, { Component } from 'react';

function Cabeçalho() {
    return (
        <div>
            <h3>Tiago Site</h3>
        </div>
    )
}
export default Cabeçalho;