import './App.css';

import Cabeçalho from './componetes/Cabeçalho';
import Rotas from "./rotas";

function App() {
  return (
    <div>
      <Cabeçalho/>
      <Rotas/>
    </div>
  )
}

export default App;
